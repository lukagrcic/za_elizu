// import "dotenv/config";
// import { db } from "./index";
// import { users } from "./schema/users";
// import bcrypt from "bcryptjs";

// async function seed() {
//   // ADMIN (nema company/country/address)
//   await db.insert(users).values({
//     email: "admin@example.com",
//     passHash: await bcrypt.hash("admin123", 10),
//     role: "ADMIN",
//     companyName: null,
//     country: null,
//     address: null,
//   });

//   // IMPORTER (ima company/country/address)
//   await db.insert(users).values({
//     email: "importer1@example.com",
//     passHash: await bcrypt.hash("importer123", 10),
//     role: "IMPORTER",
//     companyName: "Importer DOO",
//     country: "Serbia",
//     address: "Bulevar Kralja Aleksandra 1, Beograd",
//   });

//   // SUPPLIER (ima company/country/address)
//   await db.insert(users).values({
//     email: "supplier1@example.com",
//     passHash: await bcrypt.hash("supplier123", 10),
//     role: "SUPPLIER",
//     companyName: "Supplier DOO",
//     country: "Serbia",
//     address: "Knez Mihailova 10, Beograd",
//   });

//   console.log("Seed done.");
//   process.exit(0);
// }

// seed().catch((e) => {
//   console.error(e);
//   process.exit(1);
// });


import "dotenv/config";
import { db } from "./index";
import { users } from "./schema/users";
import { productCategories } from "./schema/productCategories";
import { productOffers } from "./schema/productOffers";
import bcrypt from "bcryptjs";

async function seed() {
  // ======================
  // USERS
  // ======================

  // ADMIN (nema company/country/address)
  const [admin] = await db
    .insert(users)
    .values({
      email: "admin@example.com",
      passHash: await bcrypt.hash("admin123", 10),
      role: "ADMIN",
      companyName: null,
      country: null,
      address: null,
    })
    .returning();

  // IMPORTER (ima company/country/address)
  const [importer] = await db
    .insert(users)
    .values({
      email: "importer1@example.com",
      passHash: await bcrypt.hash("importer123", 10),
      role: "IMPORTER",
      companyName: "Importer DOO",
      country: "Serbia",
      address: "Bulevar Kralja Aleksandra 1, Beograd",
    })
    .returning();

  // SUPPLIER (ima company/country/address)
  const [supplier] = await db
    .insert(users)
    .values({
      email: "supplier1@example.com",
      passHash: await bcrypt.hash("supplier123", 10),
      role: "SUPPLIER",
      companyName: "Supplier DOO",
      country: "Serbia",
      address: "Knez Mihailova 10, Beograd",
    })
    .returning();

  // ======================
  // PRODUCT CATEGORIES (TECH ONLY)
  // ======================

  const [phones] = await db
    .insert(productCategories)
    .values({ name: "Phones" })
    .returning();

  const [laptops] = await db
    .insert(productCategories)
    .values({ name: "Laptops" })
    .returning();

  const [tablets] = await db
    .insert(productCategories)
    .values({ name: "Tablets" })
    .returning();

  const [accessories] = await db
    .insert(productCategories)
    .values({ name: "Accessories" })
    .returning();

  // ======================
  // PRODUCT OFFERS (product = offer) (TECH ONLY)
  // width/height/depth: cm
  // weight: kg (optional)
  // price: numeric -> stavljamo kao string "xxx.xx"
  // ======================

  await db.insert(productOffers).values([
    // PHONES
    {
      supplierId: supplier.id,
      categoryId: phones.id,
      code: "IP15-128",
      name: "iPhone 15",
      description: "Apple iPhone 15, 128GB",
      imageUrl: "https://example.com/iphone15.jpg",
      price: "800.00",
      width: 7.1,
      height: 14.7,
      depth: 0.8,
    },
    {
      supplierId: supplier.id,
      categoryId: phones.id,
      code: "SGS24-256",
      name: "Samsung Galaxy S24",
      description: "Samsung Galaxy S24, 256GB",
      imageUrl: "https://example.com/galaxys24.jpg",
      price: "750.00",
      width: 7.0,
      height: 14.6,
      depth: 0.8,
    },

    // LAPTOPS
    {
      supplierId: supplier.id,
      categoryId: laptops.id,
      code: "MBA-M2-13",
      name: "MacBook Air M2",
      description: "Apple MacBook Air M2, 13-inch",
      imageUrl: "https://example.com/macbookairm2.jpg",
      price: "1200.00",
      width: 30.4,
      height: 21.5,
      depth: 1.1,
    },
    {
      supplierId: supplier.id,
      categoryId: laptops.id,
      code: "XPS13-I7",
      name: "Dell XPS 13",
      description: "Dell XPS 13, Intel i7",
      imageUrl: "https://example.com/dellxps13.jpg",
      price: "1100.00",
      width: 29.6,
      height: 19.9,
      depth: 1.5,
    },

    // TABLETS
    {
      supplierId: supplier.id,
      categoryId: tablets.id,
      code: "IPAD-PRO-11",
      name: 'iPad Pro 11"',
      description: "Apple iPad Pro 11-inch",
      imageUrl: "https://example.com/ipadpro11.jpg",
      price: "900.00",
      width: 24.7,
      height: 17.8,
      depth: 0.6,
    },
    {
      supplierId: supplier.id,
      categoryId: tablets.id,
      code: "TAB-S9",
      name: "Samsung Galaxy Tab S9",
      description: "Samsung Galaxy Tab S9, 128GB",
      imageUrl: "https://example.com/galaxytabs9.jpg",
      price: "650.00",
      width: 25.4,
      height: 16.6,
      depth: 0.6,
    },

    // ACCESSORIES
    {
      supplierId: supplier.id,
      categoryId: accessories.id,
      code: "CHARGER-65W",
      name: "USB-C Charger 65W",
      description: "Fast USB-C charger 65W",
      imageUrl: "https://example.com/charger65w.jpg",
      price: "45.00",
      width: 6,
      height: 6,
      depth: 3,
    },
    {
      supplierId: supplier.id,
      categoryId: accessories.id,
      code: "MOUSE-WLS",
      name: "Wireless Mouse",
      description: "Wireless mouse (USB receiver / Bluetooth)",
      imageUrl: "https://example.com/wirelessmouse.jpg",
      price: "25.00",
      width: 6.5,
      height: 11.0,
      depth: 3.8,
    },
  ]);

  console.log("✅ Seed done.");
  process.exit(0);
}

seed().catch((e) => {
  console.error("❌ Seed error:", e);
  process.exit(1);
});
