"use client";

type Role = "ADMIN" | "IMPORTER" | "SUPPLIER";

export default function Sidebar({ role }: { role: Role }) {
  const links =
    role === "ADMIN"
      ? [
          { href: "/admin/users", label: "Users" },
          { href: "/admin/collaborations", label: "Collaborations" }
        ]
      : role === "SUPPLIER"
      ? [
          { href: "/dashboard", label: "Dashboard" },
          { href: "/supplier", label: "Supplier Home" },
          { href: "/supplier/offers", label: "My Offers" },
        ]
      : [
          { href: "/dashboard", label: "Dashboard" },
          { href: "/importer", label: "Importer Home" },
          { href: "/importer/offers", label: "Offers" },
        ];

  return (
    <aside className="w-full md:w-64 md:min-h-screen border-b md:border-b-0 md:border-r bg-white">
      <div className="p-5">
        <div className="text-lg font-semibold text-gray-900">Importers App</div>
        <div className="mt-1 text-sm text-gray-600">Role: {role}</div>
      </div>

      <nav className="px-3 pb-4 space-y-1">
        {links.map((l) => (
          <a
            key={l.href}
            href={l.href}
            className="block rounded-xl px-3 py-2 text-gray-800 hover:bg-gray-100"
          >
            {l.label}
          </a>
        ))}
      </nav>
    </aside>
  );
}
