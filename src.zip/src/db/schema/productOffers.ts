import {
  pgTable,
  uuid,
  varchar,
  text,
  timestamp,
  numeric,
  real,
} from "drizzle-orm/pg-core";
import { users } from "./users";
import { productCategories } from "./productCategories";

export const productOffers = pgTable("product_offer", {
  id: uuid("id").defaultRandom().primaryKey(),

  // supplier koji nudi proizvod
  supplierId: uuid("supplier_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),

  // kategorija proizvoda
  categoryId: uuid("category_id")
    .notNull()
    .references(() => productCategories.id, { onDelete: "restrict" }),

  // šifra proizvoda (code)
  code: varchar("code", { length: 64 }).notNull(),

  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),

  imageUrl: text("image_url").notNull(),

  // cena po komadu
  price: numeric("price", { precision: 12, scale: 2 }).notNull(),

  // dimenzije
  width: real("width").notNull(),
  height: real("height").notNull(),
  depth: real("depth").notNull(),


  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});
