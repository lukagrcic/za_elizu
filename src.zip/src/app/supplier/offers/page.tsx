"use client";

import { useEffect, useMemo, useState } from "react";
import Sidebar from "@/components/Sidebar";

type SupplierOfferDto = {
  id: string;
  categoryId: string;
  categoryName: string; //DODAJ
  code: string;
  name: string;
  description: string | null;
  imageUrl: string;
  price: string;
  width: number;
  height: number;
  depth: number;
  createdAt: string;
};


type Role = "ADMIN" | "IMPORTER" | "SUPPLIER";

export default function SupplierOffersPage() {
  const [offers, setOffers] = useState<SupplierOfferDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
  const q = query.trim().toLowerCase();
  if (!q) return offers;

  return offers.filter((o) => {
    return (
      o.code.toLowerCase().includes(q) ||
      o.name.toLowerCase().includes(q) ||
      (o.description ?? "").toLowerCase().includes(q) ||
      (o.categoryName ?? "").toLowerCase().includes(q) //  DODAJ
    );
  });
}, [offers, query]);


  async function load() {
    setLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/supplier/offers", {
        method: "GET",
        credentials: "include",
        cache: "no-store",
      });

      const data = await res.json().catch(() => null);

      if (!res.ok) {
        throw new Error(data?.error ?? `GET failed (${res.status})`);
      }

      setOffers((data ?? []) as SupplierOfferDto[]);
    } catch (e: any) {
      setError(e?.message ?? "Greška pri učitavanju ponuda");
    } finally {
      setLoading(false);
    }
  }

  async function handleDelete(id: string) {
    const ok = confirm("Da li sigurno želiš da obrišeš ovu ponudu?");
    if (!ok) return;

    const prev = offers;
    setDeletingId(id);
    setOffers((cur) => cur.filter((o) => o.id !== id));

    try {
      const res = await fetch(`/api/supplier/offers/${id}`, {
        method: "DELETE",
        credentials: "include",
      });

      const data = await res.json().catch(() => null);

      if (!res.ok) {
        throw new Error(data?.error ?? `DELETE failed (${res.status})`);
      }
    } catch (e: any) {
      setOffers(prev);
      alert(e?.message ?? "Greška pri brisanju");
    } finally {
      setDeletingId(null);
    }
  }

  useEffect(() => {
    load();
  }, []);

  // Ako Sidebar traži role, hardcode jer supplier stranica
  const role: Role = "SUPPLIER";

  return (
    <main className="min-h-screen bg-gray-100">
      <div className="md:flex">
        <Sidebar role={role} />

        <section className="flex-1 p-6">
          {/* Header kao na dashboard-u */}
          <div className="flex items-start justify-between gap-4">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">My Offers</h1>
              <p className="mt-1 text-sm text-gray-600">
                Lista tvojih ponuda koje si objavio kao dobavljač.
              </p>
            </div>

            <button
              onClick={load}
              className="rounded-xl bg-black px-4 py-2 text-white hover:bg-gray-800 disabled:opacity-60"
              disabled={loading}
            >
              Osveži
            </button>
          </div>

          {/* Search bar u istom “card” fazonu */}
          <div className="mt-6 rounded-2xl bg-white p-5 shadow-sm">
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div className="text-sm text-gray-600">
                Ukupno:{" "}
                <span className="font-medium text-gray-900">{offers.length}</span>
                {query.trim() ? (
                  <>
                    {" "}
                    | Prikazano:{" "}
                    <span className="font-medium text-gray-900">
                      {filtered.length}
                    </span>
                  </>
                ) : null}
              </div>

              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Pretraga po šifri, nazivu, kategoriji, opisu…"
                className="
                  w-full md:w-96
                  rounded-xl border
                  px-3 py-2 text-sm
                  text-gray-900
                  placeholder:text-gray-500
                  outline-none
                  focus:ring-2 focus:ring-black/10
                "
              />
            </div>
          </div>

          {/* States */}
          {loading && (
            <div className="mt-4 rounded-2xl bg-white p-5 shadow-sm text-gray-700">
              Loading...
            </div>
          )}

          {!loading && error && (
            <div className="mt-4 rounded-2xl bg-white p-5 shadow-sm">
              <div className="text-red-700 font-medium">Greška</div>
              <div className="mt-1 text-sm text-red-700">{error}</div>
            </div>
          )}

          {!loading && !error && filtered.length === 0 && (
            <div className="mt-4 rounded-2xl bg-white p-5 shadow-sm text-gray-700">
              Nema ponuda za prikaz.
            </div>
          )}

          {/* Grid kartica kao na dashboard-u */}
          {!loading && !error && filtered.length > 0 && (
            <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {filtered.map((o) => (
                <OfferCard
                  key={o.id}
                  offer={o}
                  deleting={deletingId === o.id}
                  onDelete={() => handleDelete(o.id)}
                />
              ))}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}

function OfferCard({
  offer,
  deleting,
  onDelete,
}: {
  offer: SupplierOfferDto;
  deleting: boolean;
  onDelete: () => void;
}) {
  return (
    <div className="rounded-2xl bg-white p-5 shadow-sm transition hover:shadow-md">
      <div className="flex items-start gap-4">
        <img
          src={offer.imageUrl}
          alt={offer.name}
          className="h-16 w-16 rounded-xl border object-cover"
          onError={(e) => {
            const img = e.currentTarget as HTMLImageElement;
            if (img.dataset.fallback === "1") return; // već smo probali fallback
            img.dataset.fallback = "1";
            img.src = "/images/default_image.jpg";
          }}
        />


        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="text-lg font-semibold text-gray-900 truncate">
                {offer.name}
              </div>
              <div className="mt-1 flex flex-wrap items-center gap-2">
                <div className="text-sm text-gray-600 font-mono">{offer.code}</div>

                <span className="rounded-full bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-700">
                  {offer.categoryName}
                </span>
              </div>

            </div>

            <div className="text-right">
              <div className="text-sm text-gray-600">Cena</div>
              <div className="text-lg font-semibold text-gray-900">
                {formatPrice(offer.price)}
              </div>
            </div>
          </div>

          {offer.description ? (
            <div className="mt-2 text-sm text-gray-600 line-clamp-2">
              {offer.description}
            </div>
          ) : (
            <div className="mt-2 text-sm text-gray-400">Bez opisa</div>
          )}

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
            <div className="text-sm text-gray-600">
              Dimenzije:{" "}
              <span className="font-medium text-gray-900">
                {offer.width} × {offer.height} × {offer.depth}
              </span>
            </div>

            <div className="text-xs text-gray-500">
              {formatDate(offer.createdAt)}
            </div>
          </div>

          <div className="mt-4 flex items-center justify-end gap-2">
            <button
              onClick={onDelete}
              disabled={deleting}
              className="rounded-xl border border-red-300 px-4 py-2 text-sm text-red-700 hover:bg-red-50 disabled:opacity-60"
            >
              {deleting ? "Brišem..." : "Delete"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function formatDate(v: string) {
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleString();
}

function formatPrice(p: string) {
  const n = Number(p);
  if (Number.isNaN(n)) return p;
  return new Intl.NumberFormat(undefined, {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 2,
  }).format(n);
}
